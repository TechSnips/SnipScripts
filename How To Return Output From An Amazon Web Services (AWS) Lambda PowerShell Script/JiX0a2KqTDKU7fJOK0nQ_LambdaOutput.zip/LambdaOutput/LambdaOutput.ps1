# Required Modules
Install-Module AWSPowerShell -Scope CurrentUser
Install-Module AWSLambdaPSCore -Scope CurrentUser

# Import AWS Modules For Demo
Import-Module AWSPowerShell -Force
Import-Module AWSLambdaPSCore -Force

$accessKey = '***************'
$secretKey = '***************'

# Initialize default credential profile
Initialize-AWSDefaultConfiguration -AccessKey $accessKey -SecretKey $secretKey

# Publish the new PowerShell based Lambda function
$publishPSLambdaParams = @{
    Name = 'OutputTest'                            # Name of the Lambda function
    ScriptPath = '.\OutputTest\OutputTest.ps1'      # Path to the PowerShell script file
}
Publish-AWSPowerShellLambda @publishPSLambdaParams


