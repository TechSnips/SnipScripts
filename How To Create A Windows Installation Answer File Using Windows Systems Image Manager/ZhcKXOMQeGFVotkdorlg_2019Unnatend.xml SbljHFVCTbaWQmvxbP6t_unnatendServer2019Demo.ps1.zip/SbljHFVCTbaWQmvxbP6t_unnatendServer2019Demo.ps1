$mount = Mount-DiskImage C:\InstallFiles\isos\Server_STD_2019_64Bit_English_LTSC.iso  -PassThru

$driveLetter = get-volume -DiskImage $mount | select-object -ExpandProperty DriveLetter
$pathToWim = $driveLetter + ':\sources\install.wim'
Copy-Item $pathToWim 'C:\InstallFiles\wims\server2019.wim'

Dismount-DiskImage C:\InstallFiles\isos\Server_STD_2019_64Bit_English_LTSC.iso

& "C:\Program Files (x86)\Windows Kits\10\Assessment and Deployment Kit\Deployment Tools\WSIM\imgmgr.exe"

# language codes
start-process "https://docs.microsoft.com/en-us/previous-versions/windows/it-pro/windows-8.1-and-8/hh825678(v=win.10)"

#list time zones
tzutil /l | code.cmd -

code.cmd 'C:\InstallFiles\unnatends\2019Unnatend.xml' 

# Get partition layout xml examples
Start-Process "https://docs.microsoft.com/en-us/previous-versions/windows/it-pro/windows-8.1-and-8/hh825702%28v%3dwin.10%29"

# To further customize your answer file see the documentations at 
# https://docs.microsoft.com/en-us/windows-hardware/customize/desktop/unattend/components-b-unattend