﻿#Snips transcript

<#Prerequisites
1. SQL Server 2016 Server ISO
2. Windows Server ISO for the sxs Folder 
3. SSMS version 7.19
5. Folder to copy the ISO images too
6. Login as local admin 
6. sqlinstall.ps1


Optional:
At least three partions, one for SQL program install, One for DATA and one for logs.
This snip is assuming Drives C:\, E:\Data, and F:\Logs - Drive D is the mounted images. 
This install can easily be completed on a single partition. Be sure to set the directories 
in the SQLINSTALL.PS1 file. 
#>   


<#
Note about the Versions of SQL Server. 

This snip is written for SQL Server 2016. SQL Server 2017 no longer
has reporting services and is now a seperate product and download.  

#>


# After downloading the SQL Server iso, mount the image 
#To Mount the SQL Server ISO

Mount-DiskImage -ImagePath "c:\iso\en_sql_server_2016_developer_with_service_pack_2_x64_dvd_12194995.ISO"

<# 
Make note of the drive letter when mounting the image. The drive letter will be needed in the SQLINSTALL.PS1 
SOURCEPATH section of the SQLINSTALL.PSQ file 


#>

#Mount the Windows Server ISO
Mount-DiskImage -ImagePath "C:\ISO\Windows_Server_2016_Datacenter_EVAL_en-us_14393_refresh.ISO"

#Copy sxs folder to shared directory
Copy-Item "H:\sources\sxs" -Destination "C:\SQLSource\SXS" -Recurse

#The file is still in .cab format and needs to be extracted. Any third party (Winzip, WinRar) tool to extract .cab file to sxs folder.

#Copy SQL Server install files and directories to shared directory
$SQLSource = "C:\SQLSource"
Copy-Item "G:\" -Destination $SQLSource -Recurse # "G"  is my mounted ISO Image Drive 

<#
Notes for the presenter

The ISO and source files can easily be stored on a shared network drive
and do not have to be stored locally. The idea is that you do all this prep
work once, create the configuration file once and then the DSC script can be 
run on any server. 

Running this configuration will Install a basic standalone version of SQL server. No
features are included other than the main SQLENGINE. See below for other possible features 
thank can be added for the install.

Available feature codes

    Database engine = SQLENGINE
    Replication = REPLICATION
    Full-text and semantic extractions for search = FULLTEXT
    Data quality services = DQ
    Analysis services = AS
    Reporting services – native = RS
    Reporting services – sharepoint = RS_SHP
    Reporting services add-in for sharepoint products = RS_SHPWFE
    Data quality client = DQC
    SQL Server data tools = BIDS
    Client tools connectivity = CONN
    Integration services = IS
    Client tools backwards compatibility = BC
    Client tools SDK = SDK
    Documentation components = BOL
    Management tools – basic = SSMS
    Management tools – advanced = ADV_SSMS
    Distributed replay controller = DREPLAY_CTLR
    Distributed replay client = DREPLAY_CLT
    SQL client connectivity SDK = SNAC_SDK
    Master data services = MDS


The second code block (Package InstallSSMS) install version. We have to use 
the product ID so it has to be version 17.9

#>


# Install Modules
Install-Module xPSDesiredStateConfiguration
Install-Module SQLServerDSC

#Navigate to the directory with SQLInstall.ps1 file

#Compile the file 

.\SQLInstall.ps1 

# run the configuration
Start-DscConfiguration .\SQLInstall -Force -Wait -Verbose


<#Notes about the configuration file 
We are running this on a local server - 


Line 7 Install .net framework 3.5

Line 14 installs .net 4.5

Line 23 installs the features for SQL 

Line 24 is source path. 

   


#>







 

 

 