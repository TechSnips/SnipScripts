﻿Configuration SQLInstall
{
     Import-DscResource -ModuleName PSDesiredStateConfiguration 
     Import-DscResource -ModuleName SqlServerDsc
     node localhost
     {
        WindowsFeature 'NetFramework35'
        {
            Name   = 'NET-Framework-Core'
            Source = 'C:\Source\sxs' # Assumes built-in Everyone has read permission to the share and path.
            Ensure = 'Present'
        }  
        
        WindowsFeature 'NetFramework45'
          {
               Name   = 'NET-Framework-45-Core'
               Ensure = 'Present'
          }

          SqlSetup 'InstallDefaultInstance'
          {
            InstanceName         = 'DSCSQL'
            Features             = 'SQLENGINE'
            SourcePath           = 'C:\Source\SQL'
            InstallSharedDir     = 'C:\Program Files\Microsoft SQL Server'
            InstallSharedWOWDir  = 'C:\Program Files (x86)\Microsoft SQL Server'
            InstanceDir          = 'C:\Program Files\Microsoft SQL Server'
            InstallSQLDataDir    = 'E:\Data'
            SQLUserDBDir         = 'E:\Data'
            SQLUserDBLogDir      = 'F:\Logs'
            SQLTempDBDir         = 'E:\Data'
            SQLTempDBLogDir      = 'F:\Logs'
            SQLBackupDir         = 'F:\Logs'
            SQLSysAdminAccounts = @('Administrators')
            DependsOn           = '[WindowsFeature]NetFramework45'
          }

          Package InstallSSMS
        {
            Ensure = "Present"
            Name = "SSMS-Setup-ENU"
            Path = "C:\Source\ssms\SSMS-Setup-ENU.exe"
            Arguments = "/install /passive /norestart"
            ProductId = "a0010c7f-d2e9-486b-a658-a1a1106847da"
        }
        
          
     }
}

sqlinstall