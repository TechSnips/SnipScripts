$(function() {

	$("#favoritesHeader").click(function() {
		$(this).css("color","blue");
	});
	
	$(".movie-list-item").click(function() {
		$(this).css("color","red");
	});
	
	$("h3").css("background-color","yellow");
	
	$("div > ul").css("background-color","lightgray");

});

