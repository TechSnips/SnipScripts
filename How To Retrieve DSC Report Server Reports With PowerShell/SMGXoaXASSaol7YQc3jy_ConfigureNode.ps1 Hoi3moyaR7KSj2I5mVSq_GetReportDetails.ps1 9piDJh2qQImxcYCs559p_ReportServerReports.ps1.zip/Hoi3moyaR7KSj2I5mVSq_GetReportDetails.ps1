﻿
$AgentId = "3BACC5C1-6293-11E8-B2B5-00155D010416"             # Agent ID of the Node
$serviceURL = "http://server2019:8080/PSDSCPullServer.svc"    # DSC Web Service URL

$requestUri = "$serviceURL/Nodes(AgentId='$AgentId')/Reports" # URI for query
$requestUri

$request = Invoke-WebRequest -Uri $requestUri  -ContentType "application/json;odata=minimalmetadata;streaming=true;charset=utf-8" `
        -UseBasicParsing -Headers @{Accept = "application/json";ProtocolVersion = "2.0"} `
        -ErrorAction SilentlyContinue -ErrorVariable ev

$request.content

$Object = ConvertFrom-Json $request.Content

$Object.value

