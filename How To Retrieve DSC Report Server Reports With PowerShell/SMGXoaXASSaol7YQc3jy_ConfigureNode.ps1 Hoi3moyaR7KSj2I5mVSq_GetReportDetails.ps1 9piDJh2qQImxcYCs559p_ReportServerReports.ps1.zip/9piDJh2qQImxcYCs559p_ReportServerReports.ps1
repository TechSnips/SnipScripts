﻿
# Web service URL format:
# http://REPORTSERVER:8080/PSDSCReportServer.svc/Nodes(AgentId='MyNodeAgentId')/Reports

Enter-PSSession server3

Get-DscLocalConfigurationManager

$agentID = '3BACC5C1-6293-11E8-B2B5-00155D010416'

function GetReport
{
    param
    (
        $AgentId, 
        $serviceURL = "http://server2019:8080/PSDSCPullServer.svc"
    )

    $requestUri = "$serviceURL/Nodes(AgentId='$AgentId')/Reports"
    $request = Invoke-WebRequest -Uri $requestUri  -ContentType "application/json;odata=minimalmetadata;streaming=true;charset=utf-8" `
               -UseBasicParsing -Headers @{Accept = "application/json";ProtocolVersion = "2.0"} `
               -ErrorAction SilentlyContinue -ErrorVariable ev
    $object = ConvertFrom-Json $request.content
    return $object.value
}

# Get DSC reports for $agentID
GetReport -AgentId $agentID 

# Get DSC reports sorted by StartTime and select the first one
$report = GetReport -AgentId $agentID |where OperationType -eq 'Consistency' | sort StartTime -Descending | select -First 1
$report

# The real meat of the report data
$report.StatusData

# Convert StatusData from JSON
$statusData = $report.StatusData | ConvertFrom-Json
$statusData

# Get resources that in or out of desired state
$statusData.ResourcesInDesiredState
$statusData.ResourcesNotInDesiredState

$report

# Get LocalConfigurationManager reports sorted by StartTime and select the first one
$report = GetReport -AgentId $agentID | where OperationType -eq 'LocalConfigurationManager' | sort StartTime -Descending | select -First 1
$report

# Convert StatusData from JSON
$lcmStatusData = $lcm.StatusData | ConvertFrom-Json
$lcmStatusData

# View LCM job MetaConfiguration
$lcmStatusData.MetaConfiguration

$lcmStatusData.MetaConfiguration.ConfigurationDownloadManagers
