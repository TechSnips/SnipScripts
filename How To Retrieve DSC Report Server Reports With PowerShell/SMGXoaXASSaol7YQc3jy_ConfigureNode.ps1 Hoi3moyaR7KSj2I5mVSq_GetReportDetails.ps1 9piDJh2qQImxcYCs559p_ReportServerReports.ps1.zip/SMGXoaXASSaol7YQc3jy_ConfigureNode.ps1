﻿[DscLocalConfigurationManager()]
Configuration DSCConfig {
    Param([string]$NodeName = ‘localhost’)

    Node $NodeName {

        # LCM Settings
        Settings {
            RefreshFrequencyMins = 30;
            RefreshMode = “PULL”;
            ConfigurationMode = “ApplyAndAutocorrect”;
            AllowModuleOverwrite = $true;
            RebootNodeIfNeeded = $true;
            ConfigurationModeFrequencyMins = 60;
        }

        # Where to pull configurations from
        ConfigurationRepositoryWeb PullServer {
            ServerURL = “http://server2019:8080/PSDSCPullServer.svc/”
            RegistrationKey = “cb30127b-4b66-4f83-b207-c4801fb05087”
            ConfigurationNames = @(“TestConfig”)
            AllowUnsecureConnection = $true
        }

        # Report server setup. Does not need to be the same Pull server as the ConfigurationRepositoryWeb
        ReportServerWeb ReportServer {
            ServerURL = “http://server2019:8080/PSDSCPullServer.svc/”
            RegistrationKey = “cb30127b-4b66-4f83-b207-c4801fb05087”
            AllowUnsecureConnection = $true
        }
        
    }
}

DSCConfig -OutputPath C:\Config -Verbose -NodeName server3

Set-DscLocalConfigurationManager -Path C:\Config -Verbose

Invoke-Command -ComputerName server3 -ScriptBlock {(Get-DscLocalConfigurationManager).ReportManagers}
