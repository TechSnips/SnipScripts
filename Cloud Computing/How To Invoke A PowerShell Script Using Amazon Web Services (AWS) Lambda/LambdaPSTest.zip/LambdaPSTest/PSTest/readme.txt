This sample creates an empty script file for implementing a Lambda function written
in PowerShell.

The script has a Requires statement for the latest version of the AWS Tools for
PowerShell module (AWSPowerShell.NetCore) as an example for how to declare modules on
which your function is dependent and that will be bundled with your function on
deployment. If you do not need to use cmdlets from this module you can safely delete
this statement.

