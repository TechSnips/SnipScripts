Import-Module -Name 'ActiveDirectory','DSACL'

# Distinguished Name to OU where we want to delegate
$TargetDN = 'OU=Personal,OU=Users,OU=SimonW,DC=lab,DC=simonw,DC=se'

# Distinguished Name to User or Group to delegate to
$DelegateDN = 'CN=John Smith,OU=Personal,OU=Users,OU=SimonW,DC=lab,DC=simonw,DC=se'

# Credentials to use for testing
$JohnCred = Import-Clixml -Path '.\josm.cred.xml'
# Could also be:
# $JohnCred = Get-Credential