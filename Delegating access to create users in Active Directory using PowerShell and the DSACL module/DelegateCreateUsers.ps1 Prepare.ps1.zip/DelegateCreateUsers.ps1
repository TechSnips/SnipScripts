Get-ADUser -Identity 'jasm'

New-ADUser -Path $TargetDN -Name 'Jane Smith' -SamAccountName 'jasm' -Credential $JohnCred

Add-DSACLCreateChild -TargetDN $TargetDN -DelegateDN $DelegateDN -ObjectTypeName User
