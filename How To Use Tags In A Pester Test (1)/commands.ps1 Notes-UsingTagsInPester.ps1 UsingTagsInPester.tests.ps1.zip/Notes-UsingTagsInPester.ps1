# How to Use Tags in Pester

<# 
    A Scope is simply a Describe block. Adding a tag to the scope
    will allow you to include or exclude scopes when running Pester tests. 
#>

# Basic Describe block example using no tags:

Describe "My Awesome Test 1" {
    It -Name "BITS Service should be running." {
        $Status = Get-Service -ServiceName 'BITS'
        $Status.Status | Should -BeExactly 'Running'
    }
}

# Now the same example, but using a tag:

Describe "My Awesome Test 1" -Tag 'MAT1' {
    It -Name "BITS Service should be running." {
        $Status = Get-Service -ServiceName 'BITS'
        $Status.Status | Should -BeExactly 'Running'
    }
}