# We'll run this script by just using the invoke-pester cmdlet
Invoke-Pester -Script '.\UsingTagsInPester.tests.ps1'

# You can also run a pester test by just executing the script
.\UsingTagsInPester.tests.ps1

# Now let's run a tagged scope using the '-Tag' parameter
Invoke-Pester -Script .\UsingTagsInPester.tests.ps1 -Tag 'MAT1'

# Now lets run the same script, but with two tags
Invoke-Pester -Script .\UsingTagsInPester.tests.ps1 -Tag 'MAT1','MAT3'

# Now lets explicitly exclude a tagged scope
Invoke-Pester -Script .\UsingTagsInPester.tests.ps1 -ExcludeTag 'MAT1'