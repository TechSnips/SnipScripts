# This is a small scale example for using tags.

# This test should fail

Describe 'My Awesome Test 1' -Tag 'MAT1' {
    It -Name 'BITS Service should be running.' {
        $Status = Get-Service -ServiceName 'BITS'
        $Status.Status | Should -BeExactly 'Running'
    }
}

# This test should pass

Describe 'My Awesome Test 2' -Tag 'MAT2' {
    It -Name 'W32Time Service should be running.' {
        $Status = Get-Service -ServiceName 'W32Time'
        $Status.Status | Should -BeExactly 'Running'
    }
}

# This test should pass

Describe 'My Awesome Test 3' -Tag 'MAT3' {
    It -Name 'Windows Defender Service should be running.' {
        $Status = Get-Service -ServiceName 'WinDefend'
        $Status.Status | Should -BeExactly 'Running'
    }
}