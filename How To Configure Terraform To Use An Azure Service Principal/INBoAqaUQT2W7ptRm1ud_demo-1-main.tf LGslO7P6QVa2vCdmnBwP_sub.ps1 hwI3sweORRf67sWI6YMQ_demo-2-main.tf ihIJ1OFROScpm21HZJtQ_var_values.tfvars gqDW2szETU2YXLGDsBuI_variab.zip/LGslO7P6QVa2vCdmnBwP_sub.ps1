(Get-AzureRmADServicePrincipal -DisplayName SNIP*).ApplicationId
Get-AzureRmSubscription