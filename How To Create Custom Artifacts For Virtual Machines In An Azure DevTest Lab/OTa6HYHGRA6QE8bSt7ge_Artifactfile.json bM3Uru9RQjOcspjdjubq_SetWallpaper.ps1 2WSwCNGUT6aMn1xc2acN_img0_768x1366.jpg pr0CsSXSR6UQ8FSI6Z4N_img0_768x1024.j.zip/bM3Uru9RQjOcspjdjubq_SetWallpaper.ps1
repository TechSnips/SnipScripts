takeown /f C:\Windows\Web\Wallpaper\Windows\img0.jpg
takeown /f C:\Windows\Web\4K\Wallpaper\Windows\*.*

icacls C:\Windows\Web\Wallpaper\Windows\img0.jpg /Grant 'System:(F)'
icacls C:\Windows\Web\4K\Wallpaper\Windows\*.* /Grant 'System:(F)'

Remove-Item 'C:\Windows\Web\Wallpaper\Windows\img0.jpg'
Remove-Item 'C:\Windows\Web\4K\Wallpaper\Windows\*.*'

Copy-Item -Path "$PSScriptRoot\img0.jpg" -Destination 'C:\Windows\Web\Wallpaper\Windows\img0.jpg'
Get-ChildItem -Path $PSScriptRoot -Filter '*_*.jpg' | Copy-Item -Destination 'C:\Windows\Web\4K\Wallpaper\Windows\'